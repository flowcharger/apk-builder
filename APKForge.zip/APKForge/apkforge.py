#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APKForge - drop a project in, get an APK out.

Run:  python apkforge.py        (opens http://127.0.0.1:8765)

Only Python 3.8+ is required. Everything else (JDK, Android SDK, Gradle,
Node.js, Flutter) is detected and downloaded automatically on first use into
~/.apkforge. Finished APKs land in ~/APKForge-Output.

Supported inputs (zip / tar / tar.gz / tar.bz2 / tar.xz / 7z / rar / single .html):
  * Android Studio / Gradle projects (Java, Kotlin, Compose, multi-module)
  * Flutter, Capacitor / Ionic, React Native / Expo, Cordova
  * npm web apps (Vite, React, Vue, Svelte, Next export ...) -> wrapped in a WebView app
  * Plain static HTML / JS / CSS sites                       -> wrapped in a WebView app
"""
from __future__ import annotations

import colorsys
import json
import os
import platform
import re
import secrets
import shutil
import signal
import socket
import stat
import struct
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
import zipfile
import zlib
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

if sys.version_info < (3, 8):
    sys.exit("APKForge needs Python 3.8 or newer.")

VERSION = "1.0.0"
SYSTEM = platform.system()
IS_WIN = SYSTEM == "Windows"
IS_MAC = SYSTEM == "Darwin"
MACH = platform.machine().lower()
IS_ARM = MACH in ("arm64", "aarch64")

HOME = Path(os.environ.get("APKFORGE_HOME") or (Path.home() / ".apkforge"))
OUT_DIR = Path(os.environ.get("APKFORGE_OUT") or (Path.home() / "APKForge-Output"))
TOOLS = HOME / "tools"
WORK = HOME / "work"
GRADLE_HOME = HOME / "gradle-home"
KEYSTORE = HOME / "apkforge-release.keystore"
UI_FILE = Path(__file__).resolve().with_name("ui.html")

CMDLINE_TOOLS_BUILDS = ("13114758", "11076708")
NODE_VERSION = "20.18.1"
DEFAULT_BUILD_TOOLS = "34.0.0"
DEFAULT_PLATFORM = 34

TOKEN = secrets.token_urlsafe(24)
PORT = 8765
JOBS = {}
BUILD_LOCK = threading.Lock()

KIND_LABELS = {
    "gradle": "Android project (Gradle)",
    "flutter": "Flutter",
    "capacitor": "Capacitor / Ionic",
    "reactnative": "React Native",
    "expo": "Expo",
    "cordova": "Cordova",
    "webapp": "Web app (npm build)",
    "web": "Static web (HTML / JS / CSS)",
}

ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
JAVA_KEYWORDS = {"abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
                 "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
                 "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
                 "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
                 "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
                 "volatile", "while", "true", "false", "null"}


# ----------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------
class BuildError(Exception):
    def __init__(self, title, hint=""):
        super().__init__(title)
        self.title = title
        self.hint = hint


class Cancelled(Exception):
    pass


def fmt_size(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


def slugify(s, sep="-", default="app"):
    s = re.sub(r"[^A-Za-z0-9]+", sep, s or "").strip(sep)
    return s or default


def read_text(p, limit=500_000):
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore")[:limit]
    except Exception:
        return ""


def read_json(p):
    try:
        return json.loads(read_text(p))
    except Exception:
        return {}


def parse_ver(s):
    return tuple(int(x) for x in re.findall(r"\d+", str(s))[:3]) or (0,)


def rmtree(path):
    def _onerr(func, p, exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass
    shutil.rmtree(str(path), onerror=_onerr)


def exe(name):
    return name + (".exe" if IS_WIN else "")


def bat(name):
    return name + (".bat" if IS_WIN else "")


def short(s, n=260):
    s = str(s)
    return s if len(s) <= n else s[: n - 1] + "…"


# ----------------------------------------------------------------------------
# job object (state shared with the UI)
# ----------------------------------------------------------------------------
class Job:
    STAGES = [("analyze", "Analyze project"), ("toolchain", "Prepare toolchain"),
              ("build", "Build"), ("package", "Package APK")]

    def __init__(self, jid, filename, opts):
        self.id = jid
        self.filename = filename
        self.opts = opts
        self.dir = WORK / jid
        self.upload = None
        self.lines = []
        self.stages = [{"id": s, "label": l, "state": "pending", "detail": ""} for s, l in self.STAGES]
        self.state = "running"
        self.project = None
        self.result = None
        self.error = None
        self.transfer = None
        self.live = ""
        self.proc = None
        self.cancelled = False
        self.started = time.time()
        self.ended = None
        self.lock = threading.Lock()

    def log(self, text, level="info"):
        text = ANSI.sub("", str(text))
        with self.lock:
            if len(self.lines) < 60000:
                self.lines.append([level, text])

    def stage(self, sid, state, detail=None):
        with self.lock:
            for s in self.stages:
                if s["id"] == sid:
                    s["state"] = state
                    if detail is not None:
                        s["detail"] = detail

    def fail(self, title, hint=""):
        with self.lock:
            self.state = "failed"
            self.error = {"title": title, "hint": hint}
            for s in self.stages:
                if s["state"] == "active":
                    s["state"] = "error"
        self.log("✖ " + title, "err")
        if hint:
            for ln in hint.splitlines():
                self.log("  " + ln, "err")

    def check(self):
        if self.cancelled:
            raise Cancelled()

    def cancel(self):
        self.cancelled = True
        p = self.proc
        if p:
            kill_proc(p)

    def snapshot(self, since):
        with self.lock:
            return {
                "id": self.id, "state": self.state, "filename": self.filename,
                "stages": [dict(s) for s in self.stages],
                "lines": self.lines[since:], "cursor": len(self.lines),
                "transfer": self.transfer, "live": self.live,
                "project": self.project, "result": self.result, "error": self.error,
                "elapsed": (self.ended or time.time()) - self.started,
            }


def kill_proc(p):
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True)
        else:
            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
    except Exception:
        pass


def classify_line(t):
    if t.startswith("> Task") or t.startswith("> Configure"):
        return "task"
    if t.startswith("BUILD SUCCESSFUL"):
        return "ok"
    if t.startswith("BUILD FAILED") or re.search(r"(?i)\b(error|fatal|exception)\b|FAILED", t):
        return "err"
    if re.search(r"(?i)\bwarn(ing)?\b", t):
        return "warn"
    return "out"


def run(job, cmd, cwd=None, env=None, stdin_text=None, tail=500, quiet=False):
    """Run a command, stream output into the job log. Returns (returncode, tail_lines)."""
    job.check()
    shown = cmd if isinstance(cmd, str) else " ".join(str(c) for c in cmd)
    if not quiet:
        job.log("$ " + short(shown), "cmd")
    kwargs = dict(cwd=str(cwd) if cwd else None, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                  stdin=subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL, bufsize=0)
    if IS_WIN:
        if not isinstance(cmd, str):
            cmd = " ".join('"%s"' % str(a).replace('"', "") for a in cmd)
        kwargs["shell"] = True
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        cmd = [str(c) for c in cmd] if not isinstance(cmd, str) else cmd
        kwargs["start_new_session"] = True
    try:
        p = subprocess.Popen(cmd, **kwargs)
    except FileNotFoundError as e:
        raise BuildError("Required program not found", "%s\n(%s)" % (shown.split(" ")[0], e))
    job.proc = p
    if stdin_text is not None:
        def _feed():
            try:
                p.stdin.write(stdin_text.encode())
                p.stdin.close()
            except Exception:
                pass
        threading.Thread(target=_feed, daemon=True).start()
    last = deque(maxlen=tail)
    buf = b""

    def emit(text):
        text = ANSI.sub("", text).rstrip()
        if not text:
            return
        last.append(text)
        lvl = classify_line(text)
        if lvl == "task":
            job.live = text
        if not quiet:
            job.log(text, lvl)

    while True:
        chunk = p.stdout.read(65536)
        if not chunk:
            break
        buf += chunk.replace(b"\r\n", b"\n")
        while True:
            m = re.search(rb"[\r\n]", buf)
            if not m:
                break
            seg, term, buf = buf[:m.start()], buf[m.start():m.end()], buf[m.end():]
            text = seg.decode("utf-8", "replace")
            if term == b"\n":
                emit(text)
            else:
                t = ANSI.sub("", text).strip()
                if t:
                    job.live = t
        if len(buf) > 1 << 16:
            emit(buf.decode("utf-8", "replace"))
            buf = b""
    if buf:
        emit(buf.decode("utf-8", "replace"))
    rc = p.wait()
    job.proc = None
    job.live = ""
    job.check()
    return rc, list(last)


# ----------------------------------------------------------------------------
# downloading / extracting
# ----------------------------------------------------------------------------
def _download_one(job, url, dest, label):
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "APKForge/%s" % VERSION})
    done = 0
    t0 = time.time()
    last_ui = 0
    with urllib.request.urlopen(req, timeout=60) as r, open(str(tmp), "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        while True:
            job.check()
            chunk = r.read(1 << 17)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            now = time.time()
            if now - last_ui > 0.25:
                job.transfer = {"label": label, "done": done, "total": total,
                                "speed": done / max(now - t0, 0.001)}
                last_ui = now
    os.replace(str(tmp), str(dest))
    job.transfer = None
    job.log("Downloaded %s (%s)" % (label, fmt_size(done)), "ok")


def download(job, urls, dest, label):
    if isinstance(urls, str):
        urls = [urls]
    last = None
    job.log("↓ Downloading %s" % label)
    for url in urls:
        for attempt in range(3):
            try:
                _download_one(job, url, dest, label)
                return
            except Cancelled:
                raise
            except Exception as e:  # noqa
                last = e
                job.transfer = None
                job.log("Download hiccup (%s) - retrying…" % e, "warn")
                time.sleep(1.5 * (attempt + 1))
    raise BuildError("Couldn't download %s" % label,
                     "Check your internet connection, VPN, proxy or firewall, then try again.\nLast error: %s" % last)


def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "APKForge/%s" % VERSION})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def _inside(base, target):
    try:
        Path(os.path.abspath(str(target))).relative_to(Path(os.path.abspath(str(base))))
        return True
    except ValueError:
        return False


def extract_zip(zpath, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(zpath)) as z:
        for info in z.infolist():
            name = info.filename
            if name.startswith("__MACOSX/") or name.endswith(".DS_Store"):
                continue
            target = dest / name
            if not _inside(dest, target):
                continue  # zip-slip protection
            if info.is_dir() or name.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            mode = (info.external_attr >> 16) & 0xFFFF
            if not IS_WIN and stat.S_ISLNK(mode):
                try:
                    if target.exists() or target.is_symlink():
                        target.unlink()
                    os.symlink(z.read(info).decode("utf-8", "ignore"), str(target))
                except Exception:
                    pass
                continue
            with z.open(info) as src, open(str(target), "wb") as out:
                shutil.copyfileobj(src, out)
            if not IS_WIN and mode:
                try:
                    os.chmod(str(target), (mode & 0o777) | 0o600)
                except Exception:
                    pass


def extract_tar(path, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with tarfile.open(str(path)) as t:
        members = []
        for m in t.getmembers():
            if not _inside(dest, dest / m.name):
                continue
            if m.isdev():
                continue
            members.append(m)
        try:
            t.extractall(str(dest), members=members, filter="data")
        except TypeError:
            t.extractall(str(dest), members=members)


def extract_any(path, dest):
    if zipfile.is_zipfile(str(path)):
        extract_zip(path, dest)
    else:
        extract_tar(path, dest)


def unpack_upload(job, path, dest):
    """Unpack whatever the user dropped (zip, tar*, 7z, rar, gz, single html) into dest."""
    dest.mkdir(parents=True, exist_ok=True)
    with open(str(path), "rb") as f:
        head = f.read(512)
    lname = path.name.lower()
    job.log("Unpacking %s (%s)" % (path.name, fmt_size(path.stat().st_size)))
    if zipfile.is_zipfile(str(path)):
        extract_zip(path, dest)
    elif tarfile.is_tarfile(str(path)):
        extract_tar(path, dest)
    elif head.startswith(b"\x1f\x8b"):
        import gzip
        out = dest / re.sub(r"\.gz$", "", path.name, flags=re.I)
        with gzip.open(str(path), "rb") as g, open(str(out), "wb") as o:
            shutil.copyfileobj(g, o)
        if tarfile.is_tarfile(str(out)) or zipfile.is_zipfile(str(out)):
            inner = dest / "_inner"
            extract_any(out, inner)
            out.unlink()
            for c in list(inner.iterdir()):
                shutil.move(str(c), str(dest / c.name))
            inner.rmdir()
    elif head.startswith(b"7z\xbc\xaf\x27\x1c") or head.startswith(b"Rar!") or lname.endswith((".7z", ".rar")):
        _unpack_external(job, path, dest)
    elif lname.endswith((".html", ".htm")) or head.lstrip().lower().startswith((b"<!doctype html", b"<html")):
        shutil.copy2(str(path), str(dest / "index.html"))
    else:
        raise BuildError("Unsupported file type",
                         "Drop a .zip, .tar/.tar.gz/.tar.bz2/.tar.xz, .7z, .rar or a single .html file.")


def _unpack_external(job, path, dest):
    try:
        import py7zr  # type: ignore
        with py7zr.SevenZipFile(str(path)) as z:
            z.extractall(str(dest))
        return
    except ImportError:
        pass
    except Exception as e:  # noqa
        job.log("py7zr failed: %s" % e, "warn")
    for tool in ("7z", "7za", "7zr", "7zz"):
        w = shutil.which(tool)
        if w:
            rc, _ = run(job, [w, "x", "-y", "-o" + str(dest), str(path)], quiet=True)
            if rc == 0:
                return
    for tool in ("bsdtar", "tar"):
        w = shutil.which(tool)
        if w:
            rc, _ = run(job, [w, "-xf", str(path), "-C", str(dest)], quiet=True)
            if rc == 0:
                return
    raise BuildError("Can't open this archive",
                     "7z/rar archives need a helper. Install 7-Zip (or `pip install py7zr`), or re-zip the project as .zip.")


# ----------------------------------------------------------------------------
# project detection
# ----------------------------------------------------------------------------
SKIP_DIRS = {"__MACOSX", ".git", "node_modules", ".gradle", ".idea", "build", ".dart_tool", "Pods", ".svn"}
ANDROID_APP_RE = re.compile(r"com\.android\.application|android\.application|androidApplication")


def _is_android_gradle(d):
    cands = []
    for n in ("build.gradle", "build.gradle.kts"):
        cands.append(d / n)
    try:
        for sub in d.iterdir():
            if sub.is_dir() and sub.name not in SKIP_DIRS:
                for n in ("build.gradle", "build.gradle.kts"):
                    cands.append(sub / n)
    except OSError:
        pass
    return any(c.exists() and ANDROID_APP_RE.search(read_text(c)) for c in cands)


def classify(d):
    def has(*names):
        return any((d / n).exists() for n in names)

    pkg = read_json(d / "package.json") if (d / "package.json").exists() else {}
    deps = {}
    deps.update(pkg.get("dependencies") or {})
    deps.update(pkg.get("devDependencies") or {})
    scripts = pkg.get("scripts") or {}

    if (d / "pubspec.yaml").exists() and re.search(r"(?m)^\s*flutter\s*:", read_text(d / "pubspec.yaml")):
        return "flutter"
    if has("settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts") and _is_android_gradle(d):
        return "gradle"
    if has("capacitor.config.ts", "capacitor.config.json", "capacitor.config.js") or "@capacitor/core" in deps:
        return "capacitor"
    if "expo" in deps and "react-native" in deps:
        return "expo"
    if "react-native" in deps:
        return "reactnative"
    if (d / "config.xml").exists() and "<widget" in read_text(d / "config.xml") and (
            (d / "www").exists() or "cordova" in json.dumps(pkg) or (d / "platforms").exists()):
        return "cordova"
    if pkg and "build" in scripts:
        return "webapp"
    try:
        if (d / "index.html").exists() or any(c.suffix.lower() in (".html", ".htm") for c in d.iterdir() if c.is_file()):
            return "web"
    except OSError:
        pass
    return None


def find_project(dest):
    queue = deque([(dest, 0)])
    while queue:
        d, depth = queue.popleft()
        kind = classify(d)
        if kind:
            return {"kind": kind, "root": d}
        if depth < 3:
            try:
                for c in sorted(d.iterdir()):
                    if c.is_dir() and c.name not in SKIP_DIRS:
                        queue.append((c, depth + 1))
            except OSError:
                pass
    raise BuildError(
        "Couldn't recognize this project",
        "APKForge understands Android/Gradle, Flutter, Capacitor, React Native/Expo, Cordova, npm web apps and "
        "plain HTML sites.\nMake sure the archive contains the project's top-level files (e.g. settings.gradle, "
        "pubspec.yaml, package.json or index.html).")


def _title(s):
    s = re.sub(r"^@[^/]+/", "", s or "")
    s = re.sub(r"[-_.]+", " ", s).strip()
    return s.title() if s and s == s.lower() else s


def guess_name(kind, root, upload_name):
    n = None
    if kind == "flutter":
        m = re.search(r"(?m)^name:\s*(\S+)", read_text(root / "pubspec.yaml"))
        n = m.group(1) if m else None
    elif kind == "cordova":
        m = re.search(r"<name>([^<]+)</name>", read_text(root / "config.xml"))
        n = m.group(1).strip() if m else None
    elif kind == "gradle":
        for p in list(root.glob("*/src/main/res/values/strings.xml"))[:3]:
            m = re.search(r'name="app_name"[^>]*>([^<]+)<', read_text(p))
            if m:
                n = m.group(1).strip()
                break
    if not n:
        pj = read_json(root / "package.json") if (root / "package.json").exists() else {}
        n = pj.get("displayName") or pj.get("name")
    if not n and kind == "capacitor":
        m = re.search(r"appName\s*[:=]\s*['\"]([^'\"]+)['\"]", read_text(next(iter(root.glob("capacitor.config.*")), root / "x")))
        n = m.group(1) if m else None
    if not n:
        stem = re.sub(r"\.(zip|tar|gz|tgz|bz2|xz|7z|rar|html?)+$", "", upload_name, flags=re.I)
        n = stem if stem and stem != "index" else root.name
    return _title(n) or "My App"


# ----------------------------------------------------------------------------
# toolchain discovery
# ----------------------------------------------------------------------------
_java_cache = {}


def java_major(home):
    key = str(home)
    if key in _java_cache:
        return _java_cache[key]
    j = Path(home) / "bin" / exe("java")
    major = None
    if j.exists():
        try:
            r = subprocess.run([str(j), "-version"], capture_output=True, text=True, timeout=25)
            m = re.search(r'version "(\d+)(?:\.(\d+))?', r.stderr + r.stdout)
            if m:
                major = int(m.group(1))
                if major == 1 and m.group(2):
                    major = int(m.group(2))
        except Exception:
            major = None
    _java_cache[key] = major
    return major


def has_javac(home):
    return (Path(home) / "bin" / exe("javac")).exists()


def system_jdks():
    out = []
    jh = os.environ.get("JAVA_HOME")
    if jh:
        out.append(Path(jh))
    w = shutil.which("java")
    if w:
        try:
            out.append(Path(w).resolve().parent.parent)
        except Exception:
            pass
    if IS_MAC:
        for v in ("21", "17", "11"):
            try:
                r = subprocess.run(["/usr/libexec/java_home", "-v", v], capture_output=True, text=True, timeout=10)
                if r.returncode == 0 and r.stdout.strip():
                    out.append(Path(r.stdout.strip()))
            except Exception:
                pass
    elif not IS_WIN:
        for d in sorted(Path("/usr/lib/jvm").glob("*")) if Path("/usr/lib/jvm").exists() else []:
            out.append(d)
    seen, uniq = set(), []
    for p in out:
        if str(p) not in seen and p.exists():
            seen.add(str(p))
            uniq.append(p)
    return uniq


def find_java_home(root):
    root = Path(root)
    if not root.exists():
        return None
    bases = [root] + [c for c in root.iterdir() if c.is_dir()]
    for b in bases:
        for h in (b, b / "Contents" / "Home"):
            if (h / "bin" / exe("java")).exists():
                return h
    return None


JDK_CAP = [((9, 0), 25), ((8, 10), 23), ((8, 8), 22), ((8, 5), 21), ((8, 3), 20), ((8, 0), 19),
           ((7, 5), 18), ((7, 3), 17), ((7, 0), 16), ((6, 7), 15), ((0, 0), 13)]


def jdk_cap(gv):
    v = parse_ver(gv)
    for key, cap in JDK_CAP:
        if v >= key:
            return cap
    return 13


def jdk_need_for_gradle(gv):
    return 11 if parse_ver(gv) < (7, 3) else 17


AGP_TO_GRADLE = {
    (4, 0): "6.1.1", (4, 1): "6.5", (4, 2): "6.7.1", (7, 0): "7.0.2", (7, 1): "7.2", (7, 2): "7.3.3",
    (7, 3): "7.4", (7, 4): "7.5", (8, 0): "8.0", (8, 1): "8.0", (8, 2): "8.2", (8, 3): "8.4", (8, 4): "8.6",
    (8, 5): "8.7", (8, 6): "8.7", (8, 7): "8.9", (8, 8): "8.10.2", (8, 9): "8.11.1", (8, 10): "8.11.1",
    (8, 11): "8.13", (8, 12): "8.13", (8, 13): "8.13",
}


def agp_to_gradle(agp):
    if not agp:
        return "8.7"
    v = parse_ver(agp)
    if v[0] >= 9:
        return "9.1.0"
    if v[0] < 4:
        return "5.6.4"
    return AGP_TO_GRADLE.get(v[:2], "8.7" if v[0] == 8 else "7.5")


def _gradle_files(root, depth=3):
    out = []
    base = Path(root)
    for dp, dns, fns in os.walk(str(base)):
        rel = Path(dp).relative_to(base).parts
        dns[:] = [d for d in dns if d not in ("node_modules", ".git", "build", ".gradle", "intermediates")] if len(rel) < depth else []
        for f in fns:
            if f.endswith((".gradle", ".gradle.kts", ".toml", ".properties")):
                out.append(Path(dp) / f)
    return out


def parse_agp(root):
    pats = [
        r"com\.android\.tools\.build:gradle:(\d+\.\d+(?:\.\d+)?)",
        r"com\.android\.(?:application|library)[\"']\)?\s*version\s*\(?[\"'](\d+\.\d+(?:\.\d+)?)",
        r"(?m)^\s*(?:agp|androidGradlePlugin|android-gradle-plugin|gradle-plugin)\s*=\s*\"(\d+\.\d+(?:\.\d+)?)",
        r"agp_version\s*=\s*[\"'](\d+\.\d+(?:\.\d+)?)",
    ]
    for f in _gradle_files(root, 2):
        if f.name.endswith(".properties"):
            continue
        t = read_text(f)
        for p in pats:
            m = re.search(p, t)
            if m:
                return m.group(1)
    return None


def source_jdk_need(root):
    for f in _gradle_files(root, 3):
        if f.name.endswith(".properties"):
            continue
        if re.search(r"VERSION_21|JavaLanguageVersion\.of\(\s*21|jvmTarget\s*=\s*[\"']21|jvmToolchain\(\s*21", read_text(f)):
            return 21
    return 0


def scan_sdk_needs(root):
    plats, bt, ndk, cmake = set(), None, None, False
    for f in _gradle_files(root, 3):
        if f.name.endswith(".properties"):
            continue
        t = read_text(f)
        for m in re.finditer(r"compileSdk(?:Version)?\s*[=( ]\s*(?:\")?(\d+)", t):
            plats.add(int(m.group(1)))
        for m in re.finditer(r"(?m)^\s*compileSdk\s*=\s*\"?(\d+)", t):
            plats.add(int(m.group(1)))
        m = re.search(r"buildToolsVersion\s*[=( ]?\s*[\"'](\d+\.\d+\.\d+)[\"']", t)
        if m and not bt:
            bt = m.group(1)
        m = re.search(r"ndkVersion\s*[=( ]?\s*[\"']([\d.]+)[\"']", t)
        if m and not ndk:
            ndk = m.group(1)
        if "externalNativeBuild" in t and "cmake" in t.lower():
            cmake = True
    plats = {p for p in plats if 21 <= p <= 40}
    return {"platforms": plats, "build_tools": bt, "ndk": ndk, "cmake": cmake}


def sdk_root():
    for var in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        v = os.environ.get(var)
        if v and (Path(v) / "cmdline-tools" / "latest" / "bin").exists() and os.access(v, os.W_OK):
            return Path(v)
    return TOOLS / "android-sdk"


def latest_build_tools(sdk):
    d = Path(sdk) / "build-tools"
    if not d.exists():
        return None
    vers = sorted([c for c in d.iterdir() if c.is_dir() and (c / exe("zipalign")).exists()],
                  key=lambda p: parse_ver(p.name))
    return vers[-1] if vers else None


def set_props(path, kv):
    path = Path(path)
    lines = read_text(path).splitlines() if path.exists() else []
    seen = set()
    out = []
    for ln in lines:
        key = ln.split("=", 1)[0].strip()
        if key in kv:
            out.append("%s=%s" % (key, kv[key]))
            seen.add(key)
        else:
            out.append(ln)
    for k, v in kv.items():
        if k not in seen:
            out.append("%s=%s" % (k, v))
    path.write_text("\n".join(out) + "\n", encoding="utf-8")


# ----------------------------------------------------------------------------
# toolchain installer
# ----------------------------------------------------------------------------
class TC:
    def __init__(self, job):
        self.job = job
        self.sdk = sdk_root()
        self._java = {}
        self._node = None

    # ---- environment ----
    def env(self, java_home=None, extra_path=()):
        e = os.environ.copy()
        for k in ("JAVA_OPTS", "GRADLE_OPTS"):
            e.pop(k, None)
        e["GRADLE_USER_HOME"] = str(GRADLE_HOME)
        e["ANDROID_HOME"] = str(self.sdk)
        e["ANDROID_SDK_ROOT"] = str(self.sdk)
        e["TERM"] = "dumb"
        e["FLUTTER_SUPPRESS_ANALYTICS"] = "true"
        paths = []
        if java_home:
            e["JAVA_HOME"] = str(java_home)
            paths.append(Path(java_home) / "bin")
        paths += [Path(p) for p in extra_path]
        paths += [self.sdk / "platform-tools", self.sdk / "cmdline-tools" / "latest" / "bin"]
        e["PATH"] = os.pathsep.join(str(p) for p in paths) + os.pathsep + e.get("PATH", "")
        return e

    # ---- JDK ----
    def ensure_java(self, need, gradle_ver=None):
        need = max(int(need), 11)
        key = (need, gradle_ver)
        if key in self._java:
            return self._java[key]
        cap = jdk_cap(gradle_ver) if gradle_ver else 99
        hi = min(cap, need + 4)
        for h in system_jdks():
            m = java_major(h)
            if m and has_javac(h) and need <= m <= max(hi, need):
                self.job.log("Using installed JDK %s at %s" % (m, h))
                self._java[key] = h
                return h
        managed_major = 11 if need <= 11 else (17 if need <= 17 else 21)
        final = TOOLS / "jdk" / str(managed_major)
        h = find_java_home(final)
        if h and java_major(h) == managed_major:
            self._java[key] = h
            return h
        self.job.stage("toolchain", "active", "Downloading JDK %d" % managed_major)
        osn = {"Windows": "windows", "Darwin": "mac"}.get(SYSTEM, "linux")
        arch = "aarch64" if IS_ARM else "x64"
        base = "https://api.adoptium.net/v3/binary/latest/%d/ga/%s/%s/jdk/hotspot/normal/" % (managed_major, osn, arch)
        arc = TOOLS / "_dl" / ("jdk%d%s" % (managed_major, ".zip" if IS_WIN else ".tar.gz"))
        download(self.job, [base + "eclipse", base + "adoptium"], arc, "JDK %d (Temurin)" % managed_major)
        tmp = TOOLS / "jdk" / ("%d.tmp" % managed_major)
        if tmp.exists():
            rmtree(tmp)
        self.job.log("Extracting JDK…")
        extract_any(arc, tmp)
        if final.exists():
            rmtree(final)
        shutil.move(str(tmp), str(final))
        arc.unlink()
        h = find_java_home(final)
        if not h:
            raise BuildError("JDK install looks broken", "Delete %s and try again." % final)
        self.job.log("JDK %d ready" % managed_major, "ok")
        self._java[key] = h
        return h

    # ---- Android SDK ----
    def _sdkmanager(self):
        return self.sdk / "cmdline-tools" / "latest" / "bin" / bat("sdkmanager")

    def _install_cmdline_tools(self):
        osn = {"Windows": "win", "Darwin": "mac"}.get(SYSTEM, "linux")
        urls = ["https://dl.google.com/android/repository/commandlinetools-%s-%s_latest.zip" % (osn, b)
                for b in CMDLINE_TOOLS_BUILDS]
        arc = TOOLS / "_dl" / "cmdline-tools.zip"
        self.job.stage("toolchain", "active", "Downloading Android SDK tools")
        download(self.job, urls, arc, "Android SDK command-line tools")
        tmp = TOOLS / "_dl" / "cmdline-extract"
        if tmp.exists():
            rmtree(tmp)
        extract_zip(arc, tmp)
        dest = self.sdk / "cmdline-tools" / "latest"
        if dest.exists():
            rmtree(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(tmp / "cmdline-tools"), str(dest))
        rmtree(tmp)
        arc.unlink()
        if not IS_WIN:
            for f in (dest / "bin").glob("*"):
                os.chmod(str(f), 0o755)
        self.job.log("Android command-line tools installed", "ok")

    def accept_licenses(self, force=False):
        sm = self._sdkmanager()
        lic = self.sdk / "licenses" / "android-sdk-license"
        if lic.exists() and not force:
            return
        self.job.log("Accepting Android SDK licenses…")
        env = self.env(self.ensure_java(17))
        rc, _ = run(self.job, [str(sm), "--sdk_root=%s" % self.sdk, "--licenses"], env=env, stdin_text="y\n" * 80, quiet=True)
        if rc != 0:
            self.job.log("License step returned %s (continuing)" % rc, "warn")

    def sdk_install(self, pkgs, optional=()):
        sm = self._sdkmanager()
        env = self.env(self.ensure_java(17))
        allp = list(pkgs) + list(optional)
        if not allp:
            return
        self.job.stage("toolchain", "active", "Installing SDK packages")
        self.job.log("Installing: " + ", ".join(allp))
        rc, _ = run(self.job, [str(sm), "--sdk_root=%s" % self.sdk] + allp, env=env, stdin_text="y\n" * 30, quiet=False)
        if rc == 0:
            return
        for p in allp:
            rc, _ = run(self.job, [str(sm), "--sdk_root=%s" % self.sdk, p], env=env, stdin_text="y\n" * 10, quiet=True)
            if rc != 0:
                if p in optional:
                    self.job.log("Optional package %s not installed" % p, "warn")
                else:
                    raise BuildError("Couldn't install Android SDK package %s" % p,
                                     "Check your internet connection and free disk space (needs ~3 GB).")

    def ensure_sdk(self, needs=None):
        needs = needs or {}
        sm = self._sdkmanager()
        self.ensure_java(17)
        if not sm.exists():
            self._install_cmdline_tools()
        self.accept_licenses()
        bt = needs.get("build_tools") or DEFAULT_BUILD_TOOLS
        req, opt = [], []
        if not (self.sdk / "platform-tools").exists():
            req.append("platform-tools")
        if not (self.sdk / "build-tools" / bt).exists():
            (opt if needs.get("build_tools") else req).append("build-tools;%s" % bt)
        for p in sorted(set(needs.get("platforms") or []) | {DEFAULT_PLATFORM}):
            if not (self.sdk / "platforms" / ("android-%d" % p)).exists():
                (req if p == DEFAULT_PLATFORM else opt).append("platforms;android-%d" % p)
        if needs.get("ndk") and not (self.sdk / "ndk" / needs["ndk"]).exists():
            opt.append("ndk;%s" % needs["ndk"])
        if needs.get("cmake") and not (self.sdk / "cmake").exists():
            opt.append("cmake;3.22.1")
        self.sdk_install(req, opt)
        self.job.log("Android SDK ready at %s" % self.sdk, "ok")

    # ---- Gradle ----
    def ensure_gradle(self, version):
        gdir = TOOLS / "gradle" / ("gradle-%s" % version)
        g = gdir / "bin" / bat("gradle")
        if g.exists():
            return g
        self.job.stage("toolchain", "active", "Downloading Gradle %s" % version)
        arc = TOOLS / "_dl" / ("gradle-%s-bin.zip" % version)
        download(self.job, "https://services.gradle.org/distributions/gradle-%s-bin.zip" % version, arc,
                 "Gradle %s" % version)
        extract_zip(arc, TOOLS / "gradle")
        arc.unlink()
        if not IS_WIN:
            try:
                os.chmod(str(g), 0o755)
            except Exception:
                pass
        if not g.exists():
            raise BuildError("Gradle install looks broken", "Delete %s and try again." % gdir)
        self.job.log("Gradle %s ready" % version, "ok")
        return g

    # ---- Node ----
    def ensure_node(self):
        if self._node:
            return self._node
        w = shutil.which("node")
        if w:
            try:
                r = subprocess.run([w, "--version"], capture_output=True, text=True, timeout=15)
                if r.returncode == 0 and parse_ver(r.stdout)[0] >= 18 and shutil.which("npm"):
                    self.job.log("Using installed Node.js %s" % r.stdout.strip())
                    self._node = Path(w).parent
                    return self._node
            except Exception:
                pass
        plat = ("win" if IS_WIN else "darwin" if IS_MAC else "linux") + "-" + ("arm64" if IS_ARM else "x64")
        ext = "zip" if IS_WIN else ("tar.gz" if IS_MAC else "tar.xz")
        name = "node-v%s-%s" % (NODE_VERSION, plat)
        root = TOOLS / "node" / name
        bindir = root if IS_WIN else root / "bin"
        if not (bindir / exe("node")).exists():
            self.job.stage("toolchain", "active", "Downloading Node.js")
            arc = TOOLS / "_dl" / ("%s.%s" % (name, ext))
            download(self.job, "https://nodejs.org/dist/v%s/%s.%s" % (NODE_VERSION, name, ext), arc, "Node.js %s" % NODE_VERSION)
            self.job.log("Extracting Node.js…")
            extract_any(arc, TOOLS / "node")
            arc.unlink()
        self.job.log("Node.js ready", "ok")
        self._node = bindir
        return bindir

    # ---- Flutter ----
    def ensure_flutter(self):
        fdir = TOOLS / "flutter" / "flutter"
        if (fdir / "bin" / bat("flutter")).exists():
            return fdir
        self.job.stage("toolchain", "active", "Downloading Flutter SDK")
        key = {"Windows": "windows", "Darwin": "macos"}.get(SYSTEM, "linux")
        try:
            man = fetch_json("https://storage.googleapis.com/flutter_infra_release/releases/releases_%s.json" % key)
        except Exception as e:  # noqa
            raise BuildError("Couldn't reach the Flutter release server", str(e))
        cur = man["current_release"]["stable"]
        rels = [r for r in man["releases"] if r["hash"] == cur and r.get("channel") == "stable"]
        if IS_MAC:
            want = "arm64" if IS_ARM else "x64"
            rels = [r for r in rels if r.get("dart_sdk_arch") == want] or rels
        if not rels:
            raise BuildError("No stable Flutter release found for this platform")
        rel = rels[0]
        url = man["base_url"] + "/" + rel["archive"]
        arc = TOOLS / "_dl" / Path(rel["archive"]).name
        download(self.job, url, arc, "Flutter %s" % rel.get("version", "stable"))
        self.job.log("Extracting Flutter SDK (this takes a minute)…")
        extract_any(arc, TOOLS / "flutter")
        arc.unlink()
        self.job.log("Flutter ready", "ok")
        return fdir

    # ---- signing ----
    def ensure_keystore(self):
        if KEYSTORE.exists():
            return
        jh = self.ensure_java(17)
        self.job.log("Generating a release signing key (one time)…")
        rc, tail = run(self.job, [str(jh / "bin" / exe("keytool")), "-genkeypair", "-keystore", str(KEYSTORE),
                                  "-storepass", "android", "-keypass", "android", "-alias", "apkforge",
                                  "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
                                  "-dname", "CN=APKForge, O=APKForge, C=US"], quiet=True)
        if rc != 0:
            raise BuildError("Couldn't create the signing key", "\n".join(tail[-5:]))

    def sign(self, apk):
        bt = latest_build_tools(self.sdk)
        if not bt:
            raise BuildError("Build-tools missing", "Can't sign the release APK without Android build-tools.")
        self.ensure_keystore()
        env = self.env(self.ensure_java(17))
        aligned = apk.with_name(apk.stem.replace("-unsigned", "") + "-aligned.apk")
        signed = apk.with_name(apk.stem.replace("-unsigned", "") + "-signed.apk")
        za = bt / exe("zipalign")
        rc, tail = run(self.job, [str(za), "-f", "-p", "4", str(apk), str(aligned)], env=env, quiet=True)
        if rc != 0:
            raise BuildError("zipalign failed", "\n".join(tail[-5:]))
        rc, tail = run(self.job, [str(bt / bat("apksigner")), "sign", "--ks", str(KEYSTORE), "--ks-pass", "pass:android",
                                  "--key-pass", "pass:android", "--ks-key-alias", "apkforge",
                                  "--out", str(signed), str(aligned)], env=env, quiet=True)
        if rc != 0:
            raise BuildError("apksigner failed", "\n".join(tail[-5:]))
        self.job.log("Signed release APK with the APKForge key", "ok")
        return signed

    def apk_info(self, apk):
        bt = latest_build_tools(self.sdk)
        info = {}
        if not bt or not (bt / exe("aapt2")).exists():
            return info
        try:
            r = subprocess.run([str(bt / exe("aapt2")), "dump", "badging", str(apk)], capture_output=True, text=True, timeout=40)
            t = r.stdout
            m = re.search(r"package: name='([^']+)' versionCode='([^']*)' versionName='([^']*)'", t)
            if m:
                info["package"], info["versionName"] = m.group(1), m.group(3)
            m = re.search(r"application-label:'([^']*)'", t)
            if m:
                info["label"] = m.group(1)
            m = re.search(r"sdkVersion:'(\d+)'", t)
            if m:
                info["minSdk"] = int(m.group(1))
            m = re.search(r"targetSdkVersion:'(\d+)'", t)
            if m:
                info["targetSdk"] = int(m.group(1))
        except Exception:
            pass
        return info


# ----------------------------------------------------------------------------
# gradle build plumbing
# ----------------------------------------------------------------------------
INIT_SCRIPT = """allprojects {
    tasks.configureEach { t ->
        if (t.name.startsWith("lint")) { t.enabled = false }
    }
}
"""


def sanitize_gradle_project(job, root, sdk):
    """Fix the usual things that break a project that was zipped on someone else's machine."""
    root = Path(root)
    lp = root / "local.properties"
    keep = [ln for ln in read_text(lp).splitlines() if ln.strip() and not ln.startswith(("sdk.dir", "ndk.dir", "cmake.dir"))]
    keep.append("sdk.dir=%s" % Path(sdk).as_posix())
    lp.write_text("\n".join(keep) + "\n", encoding="utf-8")
    gp = root / "gradle.properties"
    if gp.exists():
        lines = read_text(gp).splitlines()
        new = [ln for ln in lines if not ln.strip().startswith("org.gradle.java.home")]
        if len(new) != len(lines):
            job.log("Auto-fix: removed machine-specific org.gradle.java.home", "ok")
            gp.write_text("\n".join(new) + "\n", encoding="utf-8")
    if "org.gradle.jvmargs" not in read_text(gp):
        set_props(gp, {"org.gradle.jvmargs": "-Xmx2048m -Dfile.encoding=UTF-8"})
    # stale caches shipped inside the archive
    for dp, dns, fns in os.walk(str(root)):
        rel = Path(dp).relative_to(root).parts
        if len(rel) > 3:
            dns[:] = []
            continue
        for d in list(dns):
            p = Path(dp) / d
            if d in ("node_modules", ".git"):
                dns.remove(d)
            elif d == ".gradle" or (d == "build" and ((Path(dp) / "build.gradle").exists() or (Path(dp) / "build.gradle.kts").exists())):
                rmtree(p)
                dns.remove(d)
    gw = root / "gradlew"
    if gw.exists():
        data = gw.read_bytes()
        if b"\r\n" in data:
            gw.write_bytes(data.replace(b"\r\n", b"\n"))
            job.log("Auto-fix: converted gradlew line endings", "ok")
        try:
            os.chmod(str(gw), 0o755)
        except Exception:
            pass


def ensure_settings(root):
    root = Path(root)
    if (root / "settings.gradle").exists() or (root / "settings.gradle.kts").exists():
        return
    mods = [c.name for c in sorted(root.iterdir()) if c.is_dir() and ((c / "build.gradle").exists() or (c / "build.gradle.kts").exists())]
    body = 'rootProject.name = "%s"\n' % slugify(root.name, "_")
    for m in mods:
        body += "include ':%s'\n" % m
    (root / "settings.gradle").write_text(body, encoding="utf-8")


def make_gradle_cmd(job, tc, root, ctx):
    root = Path(root)
    wrapper = root / bat("gradlew")
    wprops = root / "gradle" / "wrapper" / "gradle-wrapper.properties"
    wjar = root / "gradle" / "wrapper" / "gradle-wrapper.jar"
    if wrapper.exists() and wjar.exists() and not ctx.get("no_wrapper"):
        m = re.search(r"gradle-([\d.]+)-", read_text(wprops))
        gv = m.group(1) if m else None
        cmd = [str(wrapper)]
        extra = []
        job.log("Using the project's Gradle wrapper%s" % ((" (Gradle %s)" % gv) if gv else ""))
    else:
        gv = ctx.get("gradle") or agp_to_gradle(parse_agp(root))
        g = tc.ensure_gradle(gv)
        cmd = [str(g)]
        extra = [g.parent]
        job.log("Using Gradle %s" % gv)
    need = max(jdk_need_for_gradle(gv) if gv else 17, source_jdk_need(root))
    if ctx.get("jdk"):
        need = ctx["jdk"]
    ctx["cur_jdk"] = need
    jh = tc.ensure_java(need, gv)
    env = tc.env(jh, list(ctx.get("extra_path", [])) + extra)
    return cmd, env, gv


def collect_apks(root, since):
    found = []
    for dp, dns, fns in os.walk(str(root)):
        dns[:] = [d for d in dns if d not in ("node_modules", ".git", "intermediates", "androidTest", ".gradle")]
        p = Path(dp)
        if "outputs" in p.parts or "flutter-apk" in p.parts:
            for f in fns:
                if f.endswith(".apk") and "androidTest" not in f and "unaligned" not in f:
                    fp = p / f
                    if fp.stat().st_mtime >= since - 5:
                        found.append(fp)
    found.sort(key=lambda x: (0 if "flutter-apk" in x.parts else 1, str(x)))
    seen, out = set(), []
    for f in found:
        key = (f.name, f.stat().st_size)
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


def explain(tail):
    text = "\n".join(tail)
    low = text.lower()
    if re.search(r"could not (resolve|get|download)|unknownhost|connect timed out|connection reset|received status code 4|sslhandshake", low):
        m = re.search(r"(?i)could not (?:resolve|get|download) ([^\n]+)", text)
        return BuildError("Couldn't download a dependency",
                          "Gradle couldn't fetch a library%s.\nCheck your internet/VPN and try again; if the library was removed "
                          "from its repository, the project needs updating." % ((": " + m.group(1)[:140]) if m else ""))
    m = re.search(r"\* What went wrong:\s*\n((?:.*\n?){1,10})", text)
    if m:
        block = [l.rstrip() for l in m.group(1).splitlines() if l.strip() and not l.startswith("* Try")]
        title = "Source code has errors" if re.search(r"compil|execution failed for task .*(java|kotlin)", low) else "Build failed"
        errs = [l.strip() for l in tail if re.search(r"error:|e: file|\.java:\d+|\.kt:\d+", l)][:6]
        return BuildError(title, "\n".join(block[:8] + errs))
    errs = [l for l in tail if re.search(r"(?i)error|failed|exception", l)][-8:]
    return BuildError("Build failed", "\n".join(errs) or "See the log above for details.")


def diagnose(job, tc, ctx, tail):
    """Try to repair a failed build automatically. Returns True if a fix was applied (worth retrying)."""
    text = "\n".join(tail)
    low = text.lower()
    applied = ctx.setdefault("applied", set())

    def once(k):
        if k in applied:
            return False
        applied.add(k)
        return True

    gp = ctx.get("gp")
    if gp and "androidx" in low and ("useandroidx" in low or "enable androidx" in low or "android.support" in low) and once("androidx"):
        set_props(gp, {"android.useAndroidX": "true", "android.enableJetifier": "true"})
        job.log("Auto-fix: enabled AndroidX + Jetifier - retrying", "ok")
        return True
    if gp and re.search(r"java heap space|outofmemoryerror|gc overhead|metaspace|daemon .* disappeared", low) and once("mem"):
        set_props(gp, {"org.gradle.jvmargs": "-Xmx4096m -XX:MaxMetaspaceSize=1024m -Dfile.encoding=UTF-8"})
        job.log("Auto-fix: raised Gradle memory to 4 GB - retrying", "ok")
        return True
    if re.search(r"not accepted the licen[sc]e|licenses? .*not (?:been )?accepted|license for package|accept the sdk license|licen[sc]e agreements? of the following", low) and once("lic"):
        tc.accept_licenses(force=True)
        job.log("Auto-fix: re-accepted SDK licenses - retrying", "ok")
        return True
    m = re.search(r"has been compiled by a more recent version of the java runtime \(class file version (\d+)\.\d+\)", low)
    if m and once("classver"):
        ctx["jdk"] = int(m.group(1)) - 44
        job.log("Auto-fix: switching to JDK %d - retrying" % ctx["jdk"], "ok")
        return True
    m = re.search(r"(?:requires|needs) (?:java|jdk)(?: version)? (\d+)", low)
    if m and once("jdkreq%s" % m.group(1)):
        ctx["jdk"] = int(m.group(1))
        job.log("Auto-fix: switching to JDK %d - retrying" % ctx["jdk"], "ok")
        return True
    if "unsupported class file major version" in low and once("jdkdown"):
        cur = ctx.get("cur_jdk", 17)
        ctx["jdk"] = 17 if cur >= 21 else 11
        job.log("Auto-fix: this project's Gradle is too old for JDK %d, switching to JDK %d" % (cur, ctx["jdk"]), "ok")
        return True
    if re.search(r"could not find or load main class org\.gradle\.wrapper|gradlewrappermain|wrapper.*(?:corrupt|not found)", low) and once("wrapper"):
        ctx["no_wrapper"] = True
        job.log("Auto-fix: wrapper is broken, using a downloaded Gradle instead", "ok")
        return True
    m = re.search(r"failed to find build tools revision ([\d.]+)", low)
    if m and once("bt" + m.group(1)):
        tc.sdk_install(["build-tools;%s" % m.group(1)])
        return True
    m = re.search(r"failed to find target with hash string 'android-(\d+)'", low)
    if m and once("pl" + m.group(1)):
        tc.sdk_install(["platforms;android-%s" % m.group(1)])
        return True
    m = re.search(r"no version of ndk matched the requested version ([\d.]+)", low)
    if m and once("ndk" + m.group(1)):
        tc.sdk_install([], ["ndk;%s" % m.group(1)])
        return True
    if "cmake" in low and re.search(r"not found|failed to find", low) and once("cmake"):
        tc.sdk_install([], ["cmake;3.22.1"])
        return True
    return False


def gradle_flow(job, tc, root, variant, ctx=None, tasks=None):
    """Prepare everything for a Gradle project directory and build it. Toolchain stage must be active."""
    root = Path(root)
    ctx = ctx if ctx is not None else {}
    ensure_settings(root)
    needs = scan_sdk_needs(root)
    tc.ensure_sdk(needs)
    sanitize_gradle_project(job, root, tc.sdk)
    ctx["gp"] = root / "gradle.properties"
    make_gradle_cmd(job, tc, root, ctx)  # pre-download Gradle + JDK
    init = HOME / "init.gradle"
    init.write_text(INIT_SCRIPT, encoding="utf-8")
    job.stage("toolchain", "done", "Ready")
    job.stage("build", "active", "Gradle")
    since = time.time()
    tasks = tasks or ["assembleRelease" if variant == "release" else "assembleDebug"]
    for attempt in range(6):
        cmd, env, _ = make_gradle_cmd(job, tc, root, ctx)
        args = cmd + tasks + ["--no-daemon", "--console=plain", "--warning-mode=none", "-I", str(init)]
        rc, tail = run(job, args, cwd=root, env=env)
        if rc == 0:
            apks = collect_apks(root, since)
            if not apks:
                raise BuildError("Build finished but no APK was produced",
                                 "The project may only contain library modules, or builds an AAB. "
                                 "Make sure it has an `com.android.application` module.")
            return apks
        job.log("Build failed (exit %s) - looking for a fix…" % rc, "warn")
        if attempt < 5 and diagnose(job, tc, ctx, tail):
            job.stage("build", "active", "Retrying after auto-fix")
            continue
        raise explain(tail)
    raise BuildError("Build failed after several automatic fixes")


# ----------------------------------------------------------------------------
# web wrapper (static site / npm build -> WebView app)
# ----------------------------------------------------------------------------
def make_icon_png(seed, size=192):
    h = (zlib.crc32(seed.encode("utf-8")) % 360) / 360.0
    c1 = [int(v * 255) for v in colorsys.hsv_to_rgb(h, 0.62, 0.98)]
    c2 = [int(v * 255) for v in colorsys.hsv_to_rgb((h + 0.14) % 1, 0.78, 0.62)]
    rad = size * 0.22
    cx = cy = (size - 1) / 2.0
    rows = bytearray()
    for y in range(size):
        rows.append(0)
        for x in range(size):
            t = (x + y) / (2.0 * size)
            col = [c1[i] * (1 - t) + c2[i] * t for i in range(3)]
            dx = max(abs(x - cx) - (size / 2.0 - rad), 0)
            dy = max(abs(y - cy) - (size / 2.0 - rad), 0)
            dist = (dx * dx + dy * dy) ** 0.5
            a = max(0.0, min(1.0, rad - dist + 0.5))
            d = (abs(x - cx) + abs(y - cy)) / (size / 2.0)
            ring = max(0.0, min(1.0, (0.42 - d) * 14)) * (1 - max(0.0, min(1.0, (0.2 - d) * 14)))
            for i in range(3):
                col[i] = col[i] * (1 - ring) + 250 * ring
            rows += bytes((int(col[0]), int(col[1]), int(col[2]), int(a * 255)))

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b""))


def _png_width(p):
    try:
        with open(str(p), "rb") as f:
            h = f.read(24)
        if h[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">I", h[16:20])[0]
    except Exception:
        pass
    return 0


def find_site_icon(web_dir):
    names = ["icon.png", "app-icon.png", "logo.png", "icon-512.png", "icon-512x512.png", "icon-192.png", "icon-192x192.png",
             "android-chrome-512x512.png", "android-chrome-192x192.png", "apple-touch-icon.png", "favicon.png"]
    for sub in ("", "icons", "icon", "img", "images", "assets", "assets/icons", "assets/img"):
        for n in names:
            p = web_dir / sub / n
            if p.exists() and 96 <= _png_width(p) <= 1024:
                return p
    return None


MAIN_ACTIVITY = """package @@PKG@@;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                return serve(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sch = u.getScheme();
                if ("http".equals(sch) || "https".equals(sch) || "mailto".equals(sch) || "tel".equals(sch)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }
        });
        if (state != null) {
            web.restoreState(state);
        } else {
            web.loadUrl("https://" + HOST + "/index.html");
        }
    }

    private WebResourceResponse serve(Uri u) {
        String path = u.getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        path = Uri.decode(path.substring(1));
        try {
            return open(path);
        } catch (IOException e) {
            int slash = path.lastIndexOf('/');
            int dot = path.lastIndexOf('.');
            if (dot < slash || dot < 0) {
                try {
                    return open("index.html");
                } catch (IOException ignored) {
                }
            }
        }
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private WebResourceResponse open(String path) throws IOException {
        InputStream in = getAssets().open("www/" + path);
        int dot = path.lastIndexOf('.');
        String ext = dot >= 0 ? path.substring(dot + 1).toLowerCase() : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        if (mime == null) {
            switch (ext) {
                case "js": case "mjs": mime = "text/javascript"; break;
                case "wasm": mime = "application/wasm"; break;
                case "json": case "map": mime = "application/json"; break;
                case "svg": mime = "image/svg+xml"; break;
                case "woff2": mime = "font/woff2"; break;
                case "woff": mime = "font/woff"; break;
                case "ttf": mime = "font/ttf"; break;
                case "webmanifest": mime = "application/manifest+json"; break;
                default: mime = "application/octet-stream";
            }
        }
        if (ext.equals("js") || ext.equals("mjs")) mime = "text/javascript";
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-cache");
        boolean text = mime.startsWith("text/") || mime.equals("application/json") || mime.contains("javascript");
        return new WebResourceResponse(mime, text ? "utf-8" : null, 200, "OK", headers, in);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
"""

MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout|density|uiMode"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""

APP_GRADLE = """plugins {
    id 'com.android.application'
}

android {
    namespace '@@PKG@@'
    compileSdk 34

    defaultConfig {
        applicationId '@@PKG@@'
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName '@@VER@@'
    }

    buildTypes {
        release {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    androidResources {
        // keep folders such as _next/ and dotfiles that the default pattern would drop
        ignoreAssetsPattern '!.svn:!.git:!.ds_store:!*.scc:!CVS:!thumbs.db:!picasa.ini:!*~'
    }

    lint {
        abortOnError false
        checkReleaseBuilds false
    }
}
"""

ROOT_GRADLE = """plugins {
    id 'com.android.application' version '8.5.2' apply false
}
"""

SETTINGS_GRADLE = """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "@@NAME@@"
include ':app'
"""


def make_package_id(name):
    slug = re.sub(r"[^a-z0-9]", "", name.lower())
    if not slug or slug[0].isdigit() or slug in JAVA_KEYWORDS:
        slug = "app" + slug
    return "com.apkforge." + slug[:40]


def pick_web_dir(root):
    """Return the directory that actually holds the site's entry HTML."""
    root = Path(root)
    if (root / "index.html").exists():
        return root
    for sub in ("www", "public", "dist", "build", "out", "docs", "site", "web", "src"):
        if (root / sub / "index.html").exists():
            return root / sub
    hits = sorted(root.rglob("index.html"), key=lambda p: len(p.parts))
    hits = [h for h in hits if not any(part in SKIP_DIRS for part in h.relative_to(root).parts)]
    if hits:
        return hits[0].parent
    return root


def make_web_project(job, web_dir, name, dest, version="1.0"):
    web_dir = Path(web_dir)
    dest = Path(dest)
    if dest.exists():
        rmtree(dest)
    pkg = make_package_id(name)
    app = dest / "app"
    assets = app / "src" / "main" / "assets" / "www"
    java_dir = app / "src" / "main" / "java" / Path(*pkg.split("."))
    res = app / "src" / "main" / "res"
    for d in (assets, java_dir, res / "values", res / "mipmap-xxxhdpi"):
        d.mkdir(parents=True, exist_ok=True)

    ignore = shutil.ignore_patterns("node_modules", ".git", "__MACOSX", ".DS_Store", "*.apk")
    shutil.copytree(str(web_dir), str(assets), ignore=ignore, dirs_exist_ok=True)
    if not (assets / "index.html").exists():
        htmls = sorted(assets.glob("*.htm*"))
        if not htmls:
            raise BuildError("No HTML entry point found", "Add an index.html to your project.")
        shutil.copy2(str(htmls[0]), str(assets / "index.html"))
        job.log("No index.html - using %s as the entry page" % htmls[0].name, "warn")
    total = sum(f.stat().st_size for f in assets.rglob("*") if f.is_file())
    job.log("Bundled web content (%s) into the app" % fmt_size(total))

    icon = find_site_icon(assets)
    if icon:
        shutil.copy2(str(icon), str(res / "mipmap-xxxhdpi" / "ic_launcher.png"))
        job.log("Using %s as the app icon" % icon.name)
    else:
        (res / "mipmap-xxxhdpi" / "ic_launcher.png").write_bytes(make_icon_png(name))
        job.log("Generated an app icon")

    label = xml_escape(name).replace("'", "\\'").replace('"', '\\"')
    (res / "values" / "strings.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">%s</string>\n</resources>\n' % label,
        encoding="utf-8")
    (app / "src" / "main" / "AndroidManifest.xml").write_text(MANIFEST, encoding="utf-8")
    (java_dir / "MainActivity.java").write_text(MAIN_ACTIVITY.replace("@@PKG@@", pkg), encoding="utf-8")
    (app / "build.gradle").write_text(APP_GRADLE.replace("@@PKG@@", pkg).replace("@@VER@@", version), encoding="utf-8")
    (dest / "build.gradle").write_text(ROOT_GRADLE, encoding="utf-8")
    (dest / "settings.gradle").write_text(SETTINGS_GRADLE.replace("@@NAME@@", slugify(name, "_")), encoding="utf-8")
    (dest / "gradle.properties").write_text(
        "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.nonTransitiveRClass=true\n", encoding="utf-8")
    job.log("Generated Android project (%s)" % pkg)
    return pkg


# ----------------------------------------------------------------------------
# per-kind pipelines
# ----------------------------------------------------------------------------
def npm_install(job, tc, root, env):
    base = ["--no-audit", "--no-fund", "--loglevel=error"]
    cmd = ["npm", "ci" if (Path(root) / "package-lock.json").exists() else "install"] + base
    rc, tail = run(job, cmd, cwd=root, env=env)
    if rc != 0:
        job.log("Retrying npm install with --legacy-peer-deps…", "warn")
        rc, tail = run(job, ["npm", "install", "--legacy-peer-deps"] + base, cwd=root, env=env)
    if rc != 0:
        raise BuildError("npm install failed", "\n".join(tail[-8:]))


def h_gradle(job, tc, proj, variant):
    job.stage("toolchain", "active", "Android SDK · JDK · Gradle")
    return gradle_flow(job, tc, proj["root"], variant)


def h_web(job, tc, proj, variant, web_dir=None):
    job.stage("toolchain", "active", "Generating Android shell")
    wd = web_dir or pick_web_dir(proj["root"])
    work = job.dir / "shell"
    make_web_project(job, wd, proj["name"], work)
    proj["package"] = make_package_id(proj["name"])
    return gradle_flow(job, tc, work, variant)


def h_webapp(job, tc, proj, variant):
    root = proj["root"]
    job.stage("toolchain", "active", "Node.js")
    node = tc.ensure_node()
    env = tc.env(None, [node])
    job.stage("toolchain", "active", "Installing npm dependencies")
    npm_install(job, tc, root, env)
    job.stage("toolchain", "active", "Building web app")
    rc, tail = run(job, ["npm", "run", "build"], cwd=root, env=env)
    if rc != 0:
        raise BuildError("The web build failed", "\n".join(tail[-10:]))
    for sub in ("dist", "build", "out", "www", "public", ".output/public", "docs"):
        d = root / sub
        if (d / "index.html").exists():
            job.log("Web build output: %s/" % sub, "ok")
            return h_web(job, tc, proj, variant, web_dir=d)
    raise BuildError("Couldn't find the web build output",
                     "Expected an index.html in dist/, build/, out/ or www/ after `npm run build`.")


def h_capacitor(job, tc, proj, variant):
    root = proj["root"]
    job.stage("toolchain", "active", "Node.js")
    node = tc.ensure_node()
    env = tc.env(None, [node])
    job.stage("toolchain", "active", "Installing npm dependencies")
    npm_install(job, tc, root, env)
    pkg = read_json(root / "package.json")
    if "build" in (pkg.get("scripts") or {}):
        job.stage("toolchain", "active", "Building web assets")
        rc, tail = run(job, ["npm", "run", "build"], cwd=root, env=env)
        if rc != 0:
            raise BuildError("The web build failed", "\n".join(tail[-10:]))
    if not (root / "android").exists():
        deps = dict(pkg.get("dependencies") or {})
        deps.update(pkg.get("devDependencies") or {})
        if "@capacitor/android" not in deps:
            core = parse_ver(deps.get("@capacitor/core", "6"))[0]
            run(job, ["npm", "install", "@capacitor/android@%d" % core, "--no-audit", "--no-fund", "--loglevel=error"], cwd=root, env=env)
        rc, tail = run(job, ["npx", "--yes", "cap", "add", "android"], cwd=root, env=env)
        if rc != 0:
            raise BuildError("`cap add android` failed", "\n".join(tail[-8:]))
    rc, tail = run(job, ["npx", "--yes", "cap", "sync", "android"], cwd=root, env=env)
    if rc != 0:
        raise BuildError("`cap sync` failed",
                         "\n".join(tail[-8:]) + "\nTip: make sure webDir in capacitor.config points at your built web assets.")
    return gradle_flow(job, tc, root / "android", variant, ctx={"extra_path": [node]})


def h_reactnative(job, tc, proj, variant):
    root = proj["root"]
    job.stage("toolchain", "active", "Node.js")
    node = tc.ensure_node()
    env = tc.env(None, [node])
    job.stage("toolchain", "active", "Installing npm dependencies")
    npm_install(job, tc, root, env)
    if not (root / "android").exists():
        if proj["kind"] == "expo":
            rc, tail = run(job, ["npx", "--yes", "expo", "prebuild", "--platform", "android", "--no-install"], cwd=root, env=env)
            if rc != 0:
                raise BuildError("`expo prebuild` failed", "\n".join(tail[-8:]))
        else:
            raise BuildError("This React Native project has no android/ folder",
                             "Include the android/ directory in your archive.")
    if variant != "release":
        job.log("React Native debug builds need a live Metro server, so building a standalone release APK instead.", "warn")
    return gradle_flow(job, tc, root / "android", "release", ctx={"extra_path": [node]})


def h_cordova(job, tc, proj, variant):
    root = proj["root"]
    job.stage("toolchain", "active", "Node.js")
    node = tc.ensure_node()
    env = tc.env(None, [node])
    if (root / "package.json").exists():
        job.stage("toolchain", "active", "Installing npm dependencies")
        npm_install(job, tc, root, env)
    if not (root / "platforms" / "android").exists():
        rc, tail = run(job, ["npx", "--yes", "cordova", "platform", "add", "android"], cwd=root, env=env)
        if rc != 0:
            raise BuildError("`cordova platform add android` failed", "\n".join(tail[-8:]))
    rc, tail = run(job, ["npx", "--yes", "cordova", "prepare", "android"], cwd=root, env=env)
    if rc != 0:
        raise BuildError("`cordova prepare` failed", "\n".join(tail[-8:]))
    return gradle_flow(job, tc, root / "platforms" / "android", variant, ctx={"extra_path": [node]})


def h_flutter(job, tc, proj, variant):
    root = proj["root"]
    job.stage("toolchain", "active", "Flutter SDK")
    fdir = tc.ensure_flutter()
    tc.ensure_sdk({"platforms": {34, 35}})
    jh = tc.ensure_java(17)
    env = tc.env(jh, [fdir / "bin"])
    flutter = str(fdir / "bin" / bat("flutter"))
    run(job, [flutter, "config", "--android-sdk", str(tc.sdk)], cwd=root, env=env, quiet=True)
    run(job, [flutter, "config", "--jdk-dir", str(jh)], cwd=root, env=env, quiet=True)
    if not (root / "android").exists():
        job.log("No android/ folder - generating one with `flutter create`")
        pname = re.sub(r"[^a-z0-9_]", "_", proj["name"].lower()) or "app"
        if pname[0].isdigit():
            pname = "app_" + pname
        rc, tail = run(job, [flutter, "create", "--platforms=android", "--project-name", pname, "."], cwd=root, env=env)
        if rc != 0:
            raise BuildError("`flutter create` failed", "\n".join(tail[-8:]))
    sanitize_gradle_project(job, root / "android", tc.sdk)
    job.stage("toolchain", "done", "Ready")
    job.stage("build", "active", "flutter build apk")
    ctx = {"gp": root / "android" / "gradle.properties"}
    since = time.time()
    for attempt in range(4):
        rc, tail = run(job, [flutter, "build", "apk", "--release" if variant == "release" else "--debug"], cwd=root, env=env)
        if rc == 0:
            apks = collect_apks(root, since)
            if not apks:
                raise BuildError("Flutter finished but no APK was found")
            return apks
        if attempt < 3 and diagnose(job, tc, ctx, tail):
            env = tc.env(tc.ensure_java(ctx.get("jdk", 17)), [fdir / "bin"])
            continue
        raise explain(tail)


HANDLERS = {"gradle": h_gradle, "web": h_web, "webapp": h_webapp, "capacitor": h_capacitor,
            "reactnative": h_reactnative, "expo": h_reactnative, "cordova": h_cordova, "flutter": h_flutter}


# ----------------------------------------------------------------------------
# main pipeline
# ----------------------------------------------------------------------------
def package_outputs(job, tc, apks, variant, name):
    job.stage("package", "active", "Signing & collecting")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M")
    slug = slugify(name, "-", "app").lower()
    files = []
    for apk in apks:
        src = apk
        if "unsigned" in apk.name.lower():
            src = tc.sign(apk)
        low = apk.name.lower()
        kind = "release" if "release" in low else ("debug" if "debug" in low else variant)
        stem = "%s-%s" % (slug, kind) if len(apks) == 1 else "%s-%s" % (slug, re.sub(r"-?unsigned|\.apk$", "", apk.name, flags=re.I))
        out_name = "%s-%s.apk" % (stem, stamp)
        n = 2
        while (OUT_DIR / out_name).exists():
            out_name = "%s-%s-%d.apk" % (stem, stamp, n)
            n += 1
        shutil.copy2(str(src), str(OUT_DIR / out_name))
        info = tc.apk_info(OUT_DIR / out_name)
        info.update({"name": out_name, "size": (OUT_DIR / out_name).stat().st_size, "variant": kind})
        files.append(info)
        job.log("APK ready: %s (%s)" % (out_name, fmt_size(info["size"])), "ok")
    job.stage("package", "done", "%d file%s" % (len(files), "" if len(files) == 1 else "s"))
    return files


def pipeline(job):
    tc = TC(job)
    job.stage("analyze", "active", "Unpacking")
    src = job.dir / "src"
    unpack_upload(job, job.upload, src)
    proj = find_project(src)
    proj["name"] = (job.opts.get("app") or "").strip() or guess_name(proj["kind"], proj["root"], job.filename)
    label = KIND_LABELS[proj["kind"]]
    job.project = {"kind": proj["kind"], "label": label, "name": proj["name"]}
    job.log("Detected: %s - \"%s\"" % (label, proj["name"]), "ok")
    job.stage("analyze", "done", label)
    variant = "release" if job.opts.get("variant") == "release" else "debug"
    apks = HANDLERS[proj["kind"]](job, tc, proj, variant)
    job.stage("build", "done", "%d APK%s" % (len(apks), "" if len(apks) == 1 else "s"))
    files = package_outputs(job, tc, apks, variant, proj["name"])
    with job.lock:
        job.result = {"files": files, "kind": label, "name": proj["name"],
                      "duration": time.time() - job.started, "folder": str(OUT_DIR)}
        job.state = "done"
    job.log("✔ Done in %.0fs" % (time.time() - job.started), "ok")


def process(job):
    try:
        while not BUILD_LOCK.acquire(timeout=0.5):
            job.check()
            job.live = "Waiting for another build to finish…"
        job.live = ""
        try:
            pipeline(job)
        finally:
            BUILD_LOCK.release()
    except Cancelled:
        with job.lock:
            job.state = "cancelled"
            for s in job.stages:
                if s["state"] == "active":
                    s["state"] = "error"
        job.log("Build cancelled", "warn")
    except BuildError as e:
        job.fail(e.title, e.hint)
    except Exception as e:  # noqa
        job.log(traceback.format_exc(), "err")
        job.fail("Unexpected error", "%s: %s" % (type(e).__name__, e))
    finally:
        job.ended = time.time()
        job.transfer = None
        job.live = ""
        try:
            rmtree(job.dir)
        except Exception:
            pass


# ----------------------------------------------------------------------------
# environment report
# ----------------------------------------------------------------------------
def env_report():
    items = []
    need_mb = 0
    jdk_ok = None
    for h in system_jdks():
        m = java_major(h)
        if m and m >= 17 and has_javac(h):
            jdk_ok = "JDK %d (installed)" % m
            break
    if not jdk_ok:
        mh = find_java_home(TOOLS / "jdk" / "17")
        if mh and java_major(mh) == 17:
            jdk_ok = "JDK 17 (managed by APKForge)"
    items.append({"id": "jdk", "label": "Java JDK", "ready": bool(jdk_ok), "detail": jdk_ok or "JDK 17 will be downloaded (~190 MB)"})
    if not jdk_ok:
        need_mb += 190
    sdk = sdk_root()
    plats = sorted(int(p.name.split("-")[1]) for p in (sdk / "platforms").glob("android-*") if p.name.split("-")[1].isdigit()) if (sdk / "platforms").exists() else []
    sdk_ready = (sdk / "cmdline-tools" / "latest").exists() and (sdk / "platform-tools").exists() and bool(plats)
    items.append({"id": "sdk", "label": "Android SDK", "ready": sdk_ready,
                  "detail": ("API %s · build-tools %s" % (", ".join(map(str, plats[-3:])), (latest_build_tools(sdk).name if latest_build_tools(sdk) else "-")))
                  if sdk_ready else "Will be downloaded (~1 GB)"})
    if not sdk_ready:
        need_mb += 1000
    gd = sorted(p.name.replace("gradle-", "") for p in (TOOLS / "gradle").glob("gradle-*")) if (TOOLS / "gradle").exists() else []
    items.append({"id": "gradle", "label": "Gradle", "ready": bool(gd), "detail": ("Cached: " + ", ".join(gd)) if gd else "Downloaded per project (~130 MB)"})
    if not gd:
        need_mb += 130
    nd = shutil.which("node")
    mnode = any((TOOLS / "node").glob("node-*")) if (TOOLS / "node").exists() else False
    items.append({"id": "node", "label": "Node.js", "ready": bool(nd or mnode),
                  "detail": "Installed" if nd else ("Managed by APKForge" if mnode else "On demand - only for JS projects")})
    fl = (TOOLS / "flutter" / "flutter" / "bin").exists()
    items.append({"id": "flutter", "label": "Flutter", "ready": fl, "detail": "Installed" if fl else "On demand - only for Flutter projects"})
    try:
        du = shutil.disk_usage(str(HOME if HOME.exists() else HOME.parent))
        free = du.free
    except Exception:
        free = 0
    online = False
    try:
        socket.create_connection(("dl.google.com", 443), timeout=2.5).close()
        online = True
    except Exception:
        pass
    return {"items": items, "needMB": need_mb, "online": online, "freeBytes": free,
            "os": "%s %s" % (SYSTEM, platform.machine()), "home": str(HOME), "out": str(OUT_DIR), "version": VERSION}


def history():
    if not OUT_DIR.exists():
        return []
    files = sorted(OUT_DIR.glob("*.apk"), key=lambda p: p.stat().st_mtime, reverse=True)[:12]
    return [{"name": f.name, "size": f.stat().st_size, "time": f.stat().st_mtime} for f in files]


def open_folder(path):
    try:
        if IS_WIN:
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif IS_MAC:
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


# ----------------------------------------------------------------------------
# HTTP server
# ----------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "APKForge/" + VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _host_ok(self):
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]")
        if host not in ("127.0.0.1", "localhost"):
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in ("http://127.0.0.1:%d" % PORT, "http://localhost:%d" % PORT):
            return False
        return True

    def _token_ok(self, qs):
        tok = self.headers.get("X-Token") or (qs.get("t") or [""])[0]
        return secrets.compare_digest(tok, TOKEN)

    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        if u.path == "/":
            html = read_text(UI_FILE, 5_000_000) or "<h1>ui.html is missing next to apkforge.py</h1>"
            return self._send(200, html.replace("__TOKEN__", TOKEN), "text/html; charset=utf-8")
        if not self._token_ok(qs):
            return self._send(401, {"error": "bad token"})
        if u.path == "/api/env":
            return self._send(200, env_report())
        if u.path == "/api/history":
            return self._send(200, history())
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)", u.path)
        if m:
            job = JOBS.get(m.group(1))
            if not job:
                return self._send(404, {"error": "unknown job"})
            return self._send(200, job.snapshot(int((qs.get("since") or ["0"])[0] or 0)))
        m = re.fullmatch(r"/api/download/(.+)", u.path)
        if m:
            name = Path(urllib.parse.unquote(m.group(1))).name
            f = OUT_DIR / name
            if not f.exists() or f.suffix.lower() != ".apk":
                return self._send(404, {"error": "not found"})
            size = f.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % name)
            self.end_headers()
            with open(str(f), "rb") as fh:
                shutil.copyfileobj(fh, self.wfile)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self._host_ok() or not self._token_ok(qs):
            return self._send(403, {"error": "forbidden"})
        if u.path == "/api/build":
            try:
                length = int(self.headers.get("Content-Length") or -1)
            except ValueError:
                length = -1
            if length < 0:
                return self._send(411, {"error": "Content-Length required"})
            name = Path(urllib.parse.unquote((qs.get("name") or ["project"])[0])).name or "project"
            jid = uuid.uuid4().hex[:8]
            opts = {"variant": (qs.get("variant") or ["debug"])[0], "app": (qs.get("app") or [""])[0]}
            job = Job(jid, name, opts)
            (job.dir / "upload").mkdir(parents=True, exist_ok=True)
            job.upload = job.dir / "upload" / name
            remaining = length
            with open(str(job.upload), "wb") as f:
                while remaining > 0:
                    chunk = self.rfile.read(min(1 << 20, remaining))
                    if not chunk:
                        break
                    f.write(chunk)
                    remaining -= len(chunk)
            if remaining > 0:
                rmtree(job.dir)
                return self._send(400, {"error": "upload interrupted"})
            JOBS[jid] = job
            job.log("Received %s (%s)" % (name, fmt_size(length)))
            threading.Thread(target=process, args=(job,), daemon=True).start()
            return self._send(200, {"id": jid})
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)/cancel", u.path)
        if m and m.group(1) in JOBS:
            JOBS[m.group(1)].cancel()
            return self._send(200, {"ok": True})
        if u.path == "/api/open-folder":
            OUT_DIR.mkdir(parents=True, exist_ok=True)
            open_folder(OUT_DIR)
            return self._send(200, {"ok": True})
        self._send(404, {"error": "not found"})


def zip_directory(src, dest_zip):
    """Zip a folder (skipping .git / node_modules / build output) so it can go through the normal pipeline."""
    skip = {".git", "node_modules", ".gradle", ".idea", "build", ".dart_tool", "__pycache__"}
    with zipfile.ZipFile(str(dest_zip), "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dns, fns in os.walk(str(src)):
            dns[:] = [d for d in dns if d not in skip]
            for f in fns:
                fp = Path(dp) / f
                z.write(str(fp), str(fp.relative_to(src)))


def run_cli(args):
    """Headless mode for CI (GitHub Actions etc.):  python apkforge.py --cli <zip|dir|html> --out dist"""
    global OUT_DIR
    src = Path(args.cli).resolve()
    if not src.exists():
        print("::error::Input not found: %s" % src)
        return 2
    if args.out:
        OUT_DIR = Path(args.out).resolve()
    for d in (HOME, TOOLS, OUT_DIR, GRADLE_HOME, WORK):
        d.mkdir(parents=True, exist_ok=True)
    job = Job(uuid.uuid4().hex[:8], src.name if src.is_file() else src.name + ".zip",
              {"variant": args.variant, "app": args.app or ""})
    (job.dir / "upload").mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        job.upload = job.dir / "upload" / (src.name + ".zip")
        zip_directory(src, job.upload)
    else:
        job.upload = job.dir / "upload" / src.name
        shutil.copy2(str(src), str(job.upload))
    done = threading.Event()
    prefix = {"cmd": "$ ", "err": "! ", "warn": "~ ", "ok": "+ "}

    def printer():
        cur, last_stage = 0, None
        while True:
            finished = done.is_set()
            snap = job.snapshot(cur)
            for lvl, text in snap["lines"]:
                if lvl == "task":
                    continue
                print(prefix.get(lvl, "  ") + text, flush=True)
            cur = snap["cursor"]
            active = next((s for s in snap["stages"] if s["state"] == "active"), None)
            if active and active["id"] != last_stage:
                last_stage = active["id"]
                print("\n== %s ==" % active["label"], flush=True)
            if finished:
                return
            time.sleep(0.4)

    t = threading.Thread(target=printer, daemon=True)
    t.start()
    process(job)
    done.set()
    t.join(timeout=5)
    if job.state == "done":
        print("\nAPK output:")
        for f in job.result["files"]:
            print("  %s  (%s)" % (OUT_DIR / f["name"], fmt_size(f["size"])))
        return 0
    if job.error:
        print("::error title=%s::%s" % (job.error["title"], job.error["hint"].replace("\n", " | ")[:400]))
    return 1


def main():
    global PORT
    import argparse
    ap = argparse.ArgumentParser(description="APKForge - drop a project in, get an APK out.")
    ap.add_argument("--cli", metavar="INPUT", help="build INPUT (zip/tar/html file or a project folder) headlessly, no UI")
    ap.add_argument("--variant", choices=("debug", "release"), default="debug")
    ap.add_argument("--app", help="override the app name")
    ap.add_argument("--out", help="output folder for the APKs (CLI mode)")
    args = ap.parse_args()
    if args.cli:
        sys.exit(run_cli(args))
    for d in (HOME, TOOLS, OUT_DIR, GRADLE_HOME):
        d.mkdir(parents=True, exist_ok=True)
    if WORK.exists():
        rmtree(WORK)
    WORK.mkdir(parents=True, exist_ok=True)
    start = int(os.environ.get("APKFORGE_PORT", "8765"))
    server = None
    for p in range(start, start + 40):
        try:
            PORT = p
            server = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            break
        except OSError:
            continue
    if not server:
        sys.exit("Couldn't open a local port.")
    server.daemon_threads = True
    url = "http://127.0.0.1:%d/" % PORT
    print("\n  ⚒  APKForge %s\n  ─────────────────────────────" % VERSION)
    print("  UI        %s" % url)
    print("  Tools     %s" % TOOLS)
    print("  APKs      %s" % OUT_DIR)
    print("\n  Leave this window open while you use APKForge. Ctrl+C to quit.\n")
    if not os.environ.get("APKFORGE_NO_BROWSER"):
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Bye!")
        for j in JOBS.values():
            j.cancel()


if __name__ == "__main__":
    main()
