@echo off
title APKForge
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 apkforge.py
  goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python apkforge.py
  goto done
)
echo.
echo   Python 3.8 or newer is required (it is the only thing APKForge needs).
echo   Get it from https://www.python.org/downloads/  - tick "Add python.exe to PATH".
echo.
:done
pause
