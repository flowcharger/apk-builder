# APKForge

Drop a project in, get an APK out. No YAML, no Gradle setup, no SDK installation by hand.

## Run it (desktop)

1. Install **Python 3.8+** (the only prerequisite).
2. Double-click `start.bat` (Windows) or run `./start.sh` (macOS / Linux) — or `python apkforge.py`.
3. Your browser opens. Drag in a `.zip` (or `.tar.gz`, `.7z`, `.rar`, or a single `.html`).

First build downloads the toolchain (JDK 17, Android SDK, Gradle ≈ 1.3 GB) into `~/.apkforge`.
Later builds reuse it. APKs are saved to `~/APKForge-Output` and offered as a download.

## What it understands

| Project | How it's built |
|---|---|
| Android Studio / Gradle (Java, Kotlin, Compose, multi-module) | Uses the project's wrapper or a matching Gradle, picks the right JDK |
| Flutter | Downloads the Flutter SDK, `flutter build apk` |
| Capacitor / Ionic | npm install → web build → `cap sync` → Gradle |
| React Native / Expo | npm install → (expo prebuild) → release APK |
| Cordova | platform add → prepare → Gradle |
| Vite / React / Vue / Svelte / any npm web app | `npm run build` → wrapped in a WebView app |
| Plain HTML / JS / CSS | wrapped in a WebView app (offline, SPA-friendly) |

It also repairs common problems automatically: stale `local.properties`, machine-specific
`org.gradle.java.home`, CRLF `gradlew`, missing AndroidX flags, low Gradle memory, unaccepted
licenses, missing SDK platforms / build-tools / NDK, wrong JDK for the Gradle version.

**Debug** builds are signed with the standard debug key and install right away.
**Release** builds are aligned and signed with an auto-generated key stored at
`~/.apkforge/apkforge-release.keystore` (password `android`). Keep that file if you ship updates;
use your own keystore for Google Play.

## Build on GitHub (no local setup)

1. Put `apkforge.py` and `ui.html` in a repo, next to your project as `project.zip` (or a `project/` folder).
2. Add `.github/workflows/build-apk.yml` (included in this zip).
3. Push, or run it from **Actions → Build APK → Run workflow**.
4. Download the APK from the run's **Artifacts**.

Headless command used by the workflow:

```
python apkforge.py --cli project.zip --variant debug --out dist
```

## Notes

- Only build projects you trust — building runs the project's own Gradle/npm scripts.
- Everything runs locally; the UI only listens on 127.0.0.1 and is protected by a per-run token.
- Env vars: `APKFORGE_HOME` (tool cache), `APKFORGE_OUT` (APK folder), `APKFORGE_PORT`, `APKFORGE_NO_BROWSER=1`.
