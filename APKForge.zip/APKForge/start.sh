#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 apkforge.py "$@"
elif command -v python >/dev/null 2>&1; then
  exec python apkforge.py "$@"
else
  echo "Python 3.8+ is required (it is the only thing APKForge needs)."
  echo "Install it from https://www.python.org/downloads/ or your package manager."
  exit 1
fi
